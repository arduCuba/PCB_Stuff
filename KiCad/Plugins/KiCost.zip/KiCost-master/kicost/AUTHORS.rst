=======
Credits
=======

Development Lead
----------------
* XESS Corporation <info@xess.com>

------------
GUI, main collaborator and maintainer:
* Hildo Guillardi Júnior https://github.com/hildogjr

Contributors
------------
* Oliver Martin: https://github.com/oliviermartin
* Timo Alho: https://github.com/timoalho
* Steven Johnson: https://github.com/stevenj
* Diorcet Yann: https://github.com/diorcety
* Giacinto Luigi Cerone https://github.com/glcerone
* Hildo Guillardi Júnior https://github.com/hildogjr
* Adam Heinrich https://github.com/adamheinrich
* Max Maisel https://github.com/mmmaisel
* johnthagen https://github.com/johnthagen
* Frieder Schrempf https://github.com/fri-sch
* Mario DE WEERD https://github.com/mdeweerd
