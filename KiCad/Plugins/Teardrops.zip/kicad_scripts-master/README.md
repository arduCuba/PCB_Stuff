# kicad_scripts
Some kicad scripts

## Teardrops

This action plugin adds and deletes teardrops to a PCB.<br>
See the README file in the teardrops directory to get details about it.
