from __future__ import print_function, division, absolute_import
from fontTools.misc.py23 import *
from .T_S_I_V_ import table_T_S_I_V_

class table_T_S_I_B_(table_T_S_I_V_):
	pass
