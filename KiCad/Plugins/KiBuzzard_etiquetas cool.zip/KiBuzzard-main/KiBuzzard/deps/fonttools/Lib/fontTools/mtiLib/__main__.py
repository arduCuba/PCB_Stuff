from __future__ import print_function, division, absolute_import
from fontTools.misc.py23 import *
import sys
from fontTools.mtiLib import main

if __name__ == '__main__':
	sys.exit(main())
