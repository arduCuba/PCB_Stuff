##########
fixedTools
##########

.. automodule:: fontTools.misc.fixedTools
   :members:
   :undoc-members:
