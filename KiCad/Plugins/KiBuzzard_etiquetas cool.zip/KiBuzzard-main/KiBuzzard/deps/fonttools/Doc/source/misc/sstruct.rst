#######
sstruct
#######

.. automodule:: fontTools.misc.sstruct
   :members:
   :undoc-members:
