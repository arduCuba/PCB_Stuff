##############
pointInsidePen
##############

.. automodule:: fontTools.pens.pointInsidePen
   :members:
   :undoc-members:
