#########
encodings
#########

.. automodule:: fontTools.encodings
   :members:
   :undoc-members:

codecs
------

.. automodule:: fontTools.encodings.codecs
   :members:
   :undoc-members:
