#########
filterPen
#########

.. automodule:: fontTools.pens.filterPen
   :members:
   :undoc-members:
