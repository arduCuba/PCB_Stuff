.. highlight:: python

=========
filenames
=========

.. automodule:: ufoLib.filenames
   :inherited-members:
   :members:
