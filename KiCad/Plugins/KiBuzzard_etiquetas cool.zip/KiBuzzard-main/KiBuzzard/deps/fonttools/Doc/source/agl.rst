###
agl
###

.. automodule:: fontTools.agl
   :members:
   :undoc-members:
