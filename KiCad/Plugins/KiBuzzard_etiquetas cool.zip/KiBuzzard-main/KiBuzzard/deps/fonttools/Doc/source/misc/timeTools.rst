#########
timeTools
#########

.. automodule:: fontTools.misc.timeTools
   :members:
   :undoc-members:
