#############
encodingTools
#############

.. automodule:: fontTools.misc.encodingTools
   :members:
   :undoc-members:
