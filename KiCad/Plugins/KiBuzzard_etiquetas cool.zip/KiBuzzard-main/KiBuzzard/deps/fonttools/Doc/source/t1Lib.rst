#####
t1Lib
#####

.. automodule:: fontTools.t1Lib
   :members:
   :undoc-members:
